from django.shortcuts import render, redirect
from .models import Book

def index(request):
    genre_choices = ["Sci-fi", "Fantasy", "Fiction", "Non-Fiction", "Biography", "Romance", "Poetry"]
    print Book.objects.all()
    context = {
        'category': genre_choices,
        'all_books': Book.objects.all()
    }
    return render(request, "first_app/index.html", context)

def create(request):
    if request.method == 'POST':
        print request.POST
        book = Book.objects.create(title = request.POST['title'], author = request.POST['author'], category = request.POST['category'])
        print book.title
    return redirect('/')
