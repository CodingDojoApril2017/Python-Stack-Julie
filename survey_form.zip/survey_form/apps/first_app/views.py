from django.shortcuts import render, redirect

def index(request):
    locations = ["Argentina", "Unicornia", "Hogwarts", "Bumbleberry", "Georgia"]
    language = ["Python", "django", "spanish", "html", "Magic", 'Shrooms']
    context= {
    'location': locations,
    'language': language,
    }
    return render(request, "first_app/index.html", context)

def results(request):
    if request.method == 'POST':
        request.session['name'] = request.POST['name']
        print request.session['name']
        request.session['location'] = request.POST['location']
        request.session['language'] = request.POST['language']
        print request.session['language']
        request.session['comment'] = request.POST['comment']
        return render(request, 'first_app/results.html')
    else:
        return redirect('/')



# def show(request):
#     context = {
#         'name': request.session['name'],
#         'location': request.session['location'],
#         'language': request.session['language'],
#         'comment': request.session['comment'],
#     }
#     return render(request, "first_app/results.html", context)


# Create your views here.
